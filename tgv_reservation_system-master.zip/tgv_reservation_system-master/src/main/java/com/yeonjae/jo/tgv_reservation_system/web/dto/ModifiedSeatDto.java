package com.yeonjae.jo.tgv_reservation_system.web.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Getter
public class ModifiedSeatDto {
    private Long id;
    private String modifiedString;
}
